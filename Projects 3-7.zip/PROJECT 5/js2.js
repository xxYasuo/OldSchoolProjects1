

var theLeftSide = document.getElementById("leftSide");
var theRightSide = document.getElementById("rightSide");
var numberOfFaces = 5;
var theBody = document.getElementsByTagName("body")[0];



function generateFaces() {
    for (var temp = 1; temp <= numberOfFaces; temp++) {
        var img = document.createElement("img");
        img.src = "smile.png";
        img.style.top = Math.floor(Math.random() * 400) + "px";
        img.style.left = Math.floor(Math.random() * 400) + "px";
        theLeftSide.appendChild(img)
    }
    var leftSideCopy = theLeftSide.cloneNode(true);
    leftSideCopy.removeChild(leftSideCopy.lastChild);
    theRightSide.appendChild(leftSideCopy);
    theLeftSide.lastChild.onclick = function nextLevel(event) {
        event.stopPropagation();
        while (theLeftSide.firstChild) {
            theLeftSide.removeChild(theLeftSide.firstChild);
        }
        while (theRightSide.firstChild) {
            theRightSide.removeChild(theRightSide.firstChild)
        }
        numberOfFaces += 5;
        generateFaces();
    };
}


theBody.onclick = function gameOver() {
    alert("Game Over!");
    theBody.onclick = null;
    theLeftSide.lastChild.onclick = null;
    location.reload();

};
