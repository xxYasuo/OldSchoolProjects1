// Script 10.7- register.js
// This script validates a form.

// Function called when the form is submitted.
// Function validates the form data.

function validateForm(e) {
    'use strict';

    //Handles window-generated events (i.e. non-user)
    if (typeof e == 'undefined') {
        e = window.event;
    }

    //Get form object references
    var firstName = U.$("firstName");
    var lastName = U.$("lastName");
    var email = U.$("email");
    var phone = U.$("phone");
    var city = U.$("city");
    var state = U.$("state");
    var zip = U.$("zip");
    var terms = U.$("terms"); //We'll add these later....

    //Flag variable
    var error = false;

    //Validate the first name:
    if (/^[A-Z \.\-']{2,20}$/i.test(firstName.value)) {
        //Everything between / and / is the expression
        //Allows any letter A-Z (case insensitive)
        //Allows spaces, periods, and hyphens
        //Name must be 2-20 characters long

        removeErrorMessage('firstName');
    }
    else {
        addErrorMessage('firstName', 'ERROR IN FIRST NAME');
    }
         if (/^[A-Z \.\-']{2,20}$/i.test(lastName.value)) {
        removeErrorMessage('lastName');
         }
         else {
        addErrorMessage('lastName', 'ERROR IN LAST NAME');
    }

            if (/^[\w.-]+@[\w.-]+\.[A-Za-z]{2,6}$/i.test(email.value)) { //A word @ another word with a period, then A-Z
        removeErrorMessage('email');
    }
             else {
        addErrorMessage('email', 'ERROR IN EMAIL');
    }

                if (/^[0-9]{10}$/i.test(phone.value)) {
        removeErrorMessage('phone');
    }
                 else {
        addErrorMessage('phone', 'MUST BE 10 DIGITS');
    }
                    if (/^[A-Z \-']{2,20}$/i.test(city.value)) {
        removeErrorMessage('city');
    }
                      else {
        addErrorMessage('city', 'ERROR IN CITY');
    }
                        if (/^[0-9]{4,5}$/i.test(zip.value)) {
        removeErrorMessage('zip');
    }
                            else {
        addErrorMessage('zip', 'ERROR IN ZIP CODE');
    }
















    error = true;
    if (error) {
        if (e.preventDefault) {
            e.preventDefault();

        }
        else {
            e.returnValue = false;
        }
    }
    return false;

} // End of validateForm() function.

// Function called when the terms checkbox changes.
// Function enables and disables the submit button.
function toggleSubmit() {
    'use strict';

} // End of toggleSubmit() function.

// Establish functionality on window load:
window.onload = function() {
    'use strict';

    U.addEvent(
        //Takes 3 arguments:
        //1. What object is calling the event?
        //2. What is the event?
        //3. What is the handler (function)?
        U.$('theForm'),
        'submit',
        validateForm);

};